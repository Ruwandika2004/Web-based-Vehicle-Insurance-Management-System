# SafeRide Insurance Management System (SE2030)
## Comprehensive Viva Defense & Architectural Mastery Guide

**Group ID**: 2026-Y2-S1-MLB-WEB2G1-09  
**Course**: SE2030 - Software Engineering (Year 2 Semester 1 – 2026)  
**Institution**: Sri Lanka Institute of Information Technology (SLIIT)  
**Tech Stack**: Java 17/24, Spring Boot 3.2.x, Spring Data JPA, MySQL 8.0, Modern Responsive HTML5/CSS3/ES6

---

## 1. High-Level System Architecture & Flow

### 1.1 Architecture Pattern: Layered MVC with Repository Pattern
The system strictly adheres to the enterprise **Layered Architecture (Separation of Concerns)**:

```
[ Web Browser Client (HTML5 / CSS3 / ES6 Fetch API) ]
                         │  HTTP JSON (REST)
                         ▼
             [ Controller Layer (@RestController) ]
                         │  DTOs (Data Transfer Objects)
                         ▼
               [ Service Layer (@Service, Interfaces) ]
                         │  Business Logic & Validation
                         ▼
             [ Repository Layer (Spring Data JPA) ]
                         │  Hibernate ORM (JOINED Inheritance)
                         ▼
               [ Relational Database (MySQL 8.0) ]
```

1. **Presentation Layer (Static Web Portals)**:
   - Modern HTML5, CSS3 Grid/Flexbox design system (`style.css`, `dashboard.css`).
   - Centralized Fetch API client (`api.js`) handling token storage, toast notifications, error catching, and currency formatting.
   - Unified 3-Portal Login (`login.html`) with role-based routing.

2. **Controller Layer (`com.saferide.insurance.controller`)**:
   - Handles incoming HTTP requests, validates request payloads via `@Valid`, and returns standardized `ApiResponse<T>` envelopes.

3. **Service Layer (`com.saferide.insurance.service` & `impl`)**:
   - Contains all core business logic, domain invariants (e.g. claim withdrawal rules, NCB calculations, age risk loadings), and transactional boundaries (`@Transactional`).

4. **Data Access Layer (`com.saferide.insurance.repository`)**:
   - Spring Data JPA repositories extending `JpaRepository<T, ID>`, providing built-in CRUD and custom JPQL/derived queries.

5. **Domain Model Layer (`com.saferide.insurance.entity`)**:
   - Rich OOP domain models with JPA annotations, joined-table inheritance, and domain methods.

---

## 2. Core OOP Principles Demonstrated in Code

When the viva examiners ask: *"How did your group demonstrate OOP concepts?"*, here is your exact technical breakdown:

### A. Abstraction
- **Abstract Base Classes**:
  * `BaseEntity`: Abstracts audit fields (`id`, `createdAt`, `updatedAt`).
  * `User`: Abstracts common credentials and personal identity fields (`username`, `password`, `email`, `fullName`, `phone`, `role`, `active`). Defines abstract method `public abstract String getRoleDescription()`.
  * `Vehicle`: Abstracts shared motor vehicular attributes (`registrationNumber`, `chassisNumber`, `engineCapacityCc`, `fuelType`, `marketValue`, `currentMileage`). Defines abstract method `public abstract BigDecimal calculateBaseRiskFactor()`.
  * `Policy`: Abstracts policy underwriting attributes (`policyNumber`, `startDate`, `endDate`, `sumInsured`, `totalAnnualPremium`, `deductibleAmount`). Defines abstract method `public abstract String getCoverageDetailsSummary()`.
  * `PremiumQuote`: Abstracts quote calculation and validity (`calculatedSumInsured`, `baseRate`, `riskLoadingPercent`, `validUntil`). Defines abstract method `public abstract BigDecimal calculateFinalPremium()`.
  * `Claim`: Abstracts insurance claim lifecycle (`claimReference`, `incidentDate`, `incidentLocation`, `estimatedDamageAmount`, `approvedPayoutAmount`, `status`). Defines abstract methods `determineMaxPayoutLimit()` and `validateClaimEligibility()`.
  * `Inspection`: Abstracts technical examination (`inspectionReference`, `inspectionDate`, `inspectionLocation`, `status`). Defines abstract method `calculateInspectionConditionScore()`.

### B. Inheritance (`JOINED` Inheritance Strategy)
- All domain hierarchies use JPA `@Inheritance(strategy = InheritanceType.JOINED)`.
- **Why JOINED?** The base table contains common columns, and each subclass has its own specialized table joined by foreign key `id`. This achieves **3rd Normal Form (3NF)** with zero column duplication and no sparse NULL values (unlike `SINGLE_TABLE`).

```
                     ┌──────────────────┐
                     │   User (users)   │
                     └────────┬─────────┘
          ┌──────────────┬────┴─────────────┬──────────────┐
          ▼              ▼                  ▼              ▼
    ┌───────────┐ ┌──────────────┐ ┌─────────────────┐ ┌───────┐
    │ Customer  │ │ ClaimsOfficer│ │ InsuranceAgent  │ │ Admin │
    │(customers)│ │(claim_office)│ │(insurance_agent)│ │(admin)│
    └───────────┘ └──────────────┘ └─────────────────┘ └───────┘
```

### C. Polymorphism (Dynamic Method Dispatch)
1. **Actuarial Premium Calculation**:
   - `StandardQuote.calculateFinalPremium()`: Applies base risk loading + standard administrative fee.
   - `DiscountedQuote.calculateFinalPremium()`: Overrides to deduct promotional coupon discounts and multi-year loyalty percentages.
2. **Vehicle Risk Rating**:
   - `PrivateCar.calculateBaseRiskFactor()`: Weights risk based on passenger safety features.
   - `CommercialVehicle.calculateBaseRiskFactor()`: Weights risk based on tonnage capacity and goods category.
   - `Motorcycle.calculateBaseRiskFactor()`: Higher base coefficient due to two-wheeler vulnerability.
3. **Claim Payout Limiting**:
   - `AccidentClaim.determineMaxPayoutLimit()`: Capped by vehicle market value minus policy deductible.
   - `WindscreenClaim.determineMaxPayoutLimit()`: Fixed coverage cap (e.g. LKR 100,000) with zero excess penalty.
   - `TheftClaim.determineMaxPayoutLimit()`: Full sum insured payout upon police clearance confirmation.

### D. Encapsulation
- All entity fields are `private`.
- State mutation happens strictly through validated getters and setters.
- Sensitive fields like `User.password` use `@JsonIgnore` to prevent credential exposure in JSON responses.
- Domain invariants are protected (e.g. `Claim.canBeWithdrawn()` enforces that claims can only be canceled while in `SUBMITTED` or `UNDER_REVIEW` status).

---

## 3. Student-by-Student Viva Defense Sheet

---

### Student 1 (Lead): ARACHCHI A.M.R.S. (IT25102341)
- **Assigned Module**: **Online Claim Management**
- **4-Part CRUD Implementation**:
  * **CREATE**: Customer submits a new claim (Accident, Theft, Windscreen) with incident details via [`claim-submit.html`](file:///c:/Users/ruwan/OneDrive/Desktop/Isurance%20management%20system/src/main/resources/static/claim-submit.html).
  * **READ**: Real-time 5-step visual tracking timeline (`SUBMITTED` -> `UNDER_REVIEW` -> `INSPECTION_SCHEDULED` -> `APPROVED` -> `SETTLED`) via [`claim-track.html`](file:///c:/Users/ruwan/OneDrive/Desktop/Isurance%20management%20system/src/main/resources/static/claim-track.html).
  * **UPDATE**: Claims Officer reviews incident, edits assessor notes, and adjusts authorized payout amount via [`claim-manage.html`](file:///c:/Users/ruwan/OneDrive/Desktop/Isurance%20management%20system/src/main/resources/static/claim-manage.html).
  * **DELETE**: Customer withdraws pending claim (`DELETE /api/claims/{id}/withdraw`).
- **Key Java Files**: `Claim.java`, `AccidentClaim.java`, `TheftClaim.java`, `WindscreenClaim.java`, `ClaimRepository.java`, `ClaimService.java`, `ClaimServiceImpl.java`, `ClaimController.java`.
- **Top Viva Questions & Answers**:
  * **Q: How is polymorphism applied in your Claim module?**  
    *Answer: The abstract base class `Claim` defines `determineMaxPayoutLimit()` and `validateClaimEligibility()`. Subclasses `AccidentClaim`, `TheftClaim`, and `WindscreenClaim` override these methods with their respective business rules and coverage limits.*
  * **Q: How did you prevent fraudulent or illegal claim withdrawals?**  
    *Answer: In `Claim.java`, the domain method `canBeWithdrawn()` checks `status == SUBMITTED || status == UNDER_REVIEW`. If a claim is already approved or settled, an exception is thrown.*

---

### Student 2: RAVIHARA L.D.C. (IT25102267)
- **Assigned Module**: **Vehicle Management**
- **4-Part CRUD Implementation**:
  * **CREATE**: Customer registers vehicle (`PrivateCar`, `CommercialVehicle`, `Motorcycle`) with VIN, CC, and specs.
  * **READ**: Fleet listing with vehicle cards, registration numbers, and status.
  * **UPDATE**: Quick modal to edit current odometer mileage and vehicle modifications (`PUT /api/vehicles/{id}`).
  * **DELETE**: Deregister/remove sold or uninsurable vehicle from customer fleet (`DELETE /api/vehicles/{id}`).
- **Key Java Files**: `Vehicle.java`, `PrivateCar.java`, `CommercialVehicle.java`, `Motorcycle.java`, `VehicleRepository.java`, `VehicleService.java`, `VehicleServiceImpl.java`, `VehicleController.java`.
- **Top Viva Questions & Answers**:
  * **Q: How does your database represent different types of vehicles?**  
    *Answer: We use `@Inheritance(strategy = InheritanceType.JOINED)`. The parent `vehicles` table holds common columns (make, model, year, registration number, VIN). Subclass tables `private_cars`, `commercial_vehicles`, and `motorcycles` hold specific attributes and link via foreign key.*
  * **Q: What validation is enforced when registering a vehicle?**  
    *Answer: Registration number and chassis number (VIN) are marked `unique = true` in JPA and database schema to prevent duplicate vehicle registration.*

---

### Student 3: GAMAGE S.M. (IT25102293)
- **Assigned Module**: **Insurance Policy Management**
- **4-Part CRUD Implementation**:
  * **CREATE**: Issue Comprehensive or Third-Party policy linked to an insured vehicle (`POST /api/policies`).
  * **READ**: View policy certificate, sum insured, deductible, and coverage breakdown.
  * **UPDATE**: One-click 1-year policy renewal extending end date (`PUT /api/policies/{id}/renew`).
  * **DELETE**: Immediate policy cancellation terminating active coverage (`DELETE /api/policies/{id}`).
- **Key Java Files**: `Policy.java`, `ComprehensivePolicy.java`, `ThirdPartyPolicy.java`, `PolicyRepository.java`, `PolicyService.java`, `PolicyServiceImpl.java`, `PolicyController.java`.
- **Top Viva Questions & Answers**:
  * **Q: What is the difference between Comprehensive and Third-Party policies in your code?**  
    *Answer: `ComprehensivePolicy` covers own vehicle damage, natural disasters, theft, and riots with customizable deductibles. `ThirdPartyPolicy` covers legal third-party property and bodily injury with a fixed statutory coverage limit.*
  * **Q: How does the renewal method work?**  
    *Answer: `PolicyServiceImpl.renewPolicy()` validates that the policy is not already cancelled, advances `endDate` by the specified years, and sets status to `RENEWED`.*

---

### Student 4: DESHANYA T. (IT25102295)
- **Assigned Module**: **Customer Profile Management**
- **4-Part CRUD Implementation**:
  * **CREATE**: Automatic profile creation upon registration or profile initialization (`POST /api/profiles`).
  * **READ**: KYC lookup showing national identity (NIC/Passport), driving license expiry, residential address.
  * **UPDATE**: Update contact numbers, residential city, and emergency contact details (`PUT /api/profiles/{id}`).
  * **DELETE**: Deactivate/close customer profile record (`DELETE /api/profiles/{id}`).
- **Key Java Files**: `CustomerProfile.java`, `CustomerProfileRepository.java`, `CustomerProfileService.java`, `CustomerProfileServiceImpl.java`, `CustomerProfileController.java`.
- **Top Viva Questions & Answers**:
  * **Q: How is the CustomerProfile related to the User entity?**  
    *Answer: It has a `@OneToOne(fetch = FetchType.EAGER)` relationship with the `User` entity linked by `user_id` foreign key with a unique constraint.*
  * **Q: How do you verify if the customer has a valid driving license?**  
    *Answer: The domain method `CustomerProfile.isLicenseValid()` checks that `licenseExpiryDate != null && licenseExpiryDate.isAfter(LocalDate.now())`.*

---

### Student 5: SUBASINGHE S.A.K.G. (IT25102301)
- **Assigned Module**: **Premium Calculation**
- **4-Part CRUD Implementation**:
  * **CREATE**: Generate actuarial premium quote calculation (`POST /api/quotes/calculate`).
  * **READ**: Interactive breakdown displaying sum insured, base rate, vehicle age risk loading, No-Claim-Bonus (NCB) discount, and monthly installment.
  * **UPDATE**: Save quote to customer account and recalculate when vehicle parameters change.
  * **DELETE**: Remove abandoned draft quotation (`DELETE /api/quotes/{reference}`).
- **Key Java Files**: `PremiumQuote.java`, `StandardQuote.java`, `DiscountedQuote.java`, `PremiumQuoteRepository.java`, `PremiumCalculationService.java`, `PremiumCalculationServiceImpl.java`, `PremiumQuoteController.java`.
- **Top Viva Questions & Answers**:
  * **Q: What actuarial formula is implemented in your calculation service?**  
    *Answer: Base Premium = Market Value × Base Rate. Risk Loading = Base Premium × (Age × Risk Loading Factor). NCB Discount = (Base + Loading) × NCB%. Final Premium = (Base + Loading - NCB - PromoDiscount) + Admin Fee.*
  * **Q: What is the polymorphism difference between StandardQuote and DiscountedQuote?**  
    *Answer: `DiscountedQuote` checks promo code validity and subtracts additional discount percentage before calculating taxes and final payable premiums.*

---

### Student 6: SENAVIRATHNA M.D.T.D. (IT25102348)
- **Assigned Module**: **Vehicle Inspection & Damage Assessment**
- **4-Part CRUD Implementation**:
  * **CREATE**: Book Pre-Policy underwriting inspection or post-collision Damage Assessment (`POST /api/inspections`).
  * **READ**: View inspection reports, technical score (1-10), and damaged parts queue.
  * **UPDATE**: Technical Assessor updates damage severity (`MINOR`, `MODERATE`, `SEVERE`), parts to replace, and labor repair cost estimate (`PUT /api/inspections/{id}`).
  * **DELETE**: Cancel duplicate or invalid inspection request (`DELETE /api/inspections/{id}`).
- **Key Java Files**: `Inspection.java`, `PrePolicyInspection.java`, `DamageAssessment.java`, `InspectionRepository.java`, `InspectionService.java`, `InspectionServiceImpl.java`, `InspectionController.java`.
- **Top Viva Questions & Answers**:
  * **Q: Why are Inspections split into PrePolicyInspection and DamageAssessment?**  
    *Answer: Pre-policy inspections evaluate overall vehicle health, odometer accuracy, and roadworthiness before issuing coverage. Damage assessments evaluate collision impact, structural chassis damage, and repair cost estimations for claim reimbursement.*
  * **Q: How does your damage severity enum affect the repair estimate?**  
    *Answer: In `DamageAssessment`, severity flags (`MINOR`, `MODERATE`, `SEVERE`) validate the estimated repair cost against policy coverage caps.*

---

## 4. Live Viva Demonstration Script (5-Minute Walkthrough)

When presenting to the lecturers, follow this exact sequence:

1. **Step 1: The Unified Login Portal (`http://localhost:8080/login.html`)**:
   - Show the 3 distinct portal tabs: **Customer**, **Staff & Officer**, and **Executive Admin**.
   - Click the **1-Click Customer Login** chip (`customer_sunil`) to enter the Customer Portal.

2. **Step 2: Customer Fleet & Policy Overview**:
   - Show Sunil's registered vehicles (`WP-CAB-4521` Prius Hybrid).
   - Demonstrate **Module 2 (Vehicle CRUD)**: Click "Edit Mileage" on a vehicle, change value, click Save (Update), then click "Register New Vehicle" (Create).
   - Demonstrate **Module 3 (Policy CRUD)**: View active policy `POL-2026-COMP-001`, click "Renew (1 Year)" to demonstrate renewal.

3. **Step 3: Premium Calculation Engine**:
   - Navigate to `/premium-calculator.html` (**Module 5**).
   - Adjust vehicle age, market value, and NCB discount. Show real-time actuarial calculation breakdown and monthly installment. Click "Save Quotation".

4. **Step 4: Claim Filing & Live Tracking**:
   - Navigate to `/claim-submit.html` (**Module 1 - Lead**).
   - Select policy, choose "Road Traffic Accident", enter description, and submit.
   - It redirects to `/claim-track.html` showing the 5-step visual timeline (`SUBMITTED`). Show the "Withdraw Claim" button.

5. **Step 5: Claims Officer Adjudication**:
   - Click Logout. On `/login.html`, switch to **Staff & Officer Tab** and click 1-Click login as `officer_nimal`.
   - On `/claim-manage.html`, open the newly filed claim, enter Assessor Findings, adjust payout amount, and click **Approve Claim**.
   - Show `/inspection-management.html` (**Module 6**) to show the damage assessment report with repair costs and parts to replace.

6. **Step 6: Executive Admin Analytics**:
   - Log in as `admin` on `/login.html`.
   - Show `/admin-dashboard.html` displaying corporate financial summaries, total claims settled, and the User Governance table (Activate/Deactivate toggle).

---
**SafeRide Insurance System is complete, documented, and ready for your presentation!**
